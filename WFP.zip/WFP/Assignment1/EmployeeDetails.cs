﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1
{
    public partial class EmployeeDetails : Form
    {
        public EmployeeDetails()
        {
            InitializeComponent();
        }

        Repository.EmployeeDetailsDAO EmpDAO = new Repository.EmployeeDetailsDAO();
        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                MessageBox.Show("Please enter employee name.", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtName.Focus();
            }
        }

        private void msktxtDoB_Leave(object sender, EventArgs e)
        {
            if (!msktxtDoB.MaskCompleted)
            {
                MessageBox.Show("Please enter date of birth.", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                msktxtDoB.Focus();
            }
        }

        private void msktxtDatedJoinning_Leave(object sender, EventArgs e)
        {
            if (!msktxtDatedJoinning.MaskCompleted)
            {
                MessageBox.Show("Please enter dated of joinning.", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                msktxtDatedJoinning.Focus();
            }
        }

        private void msktxtPhone_Leave(object sender, EventArgs e)
        {
            if (!msktxtPhone.MaskCompleted)
            {
                MessageBox.Show("Please enter your phone number. (000-0000)", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                msktxtPhone.Focus();
            }
        }

        private void txtAddress_Leave(object sender, EventArgs e)
        {
            if (txtAddress.Text == "")
            {
                MessageBox.Show("Please enter your address.", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            /*if (txtEmail.Text == "")
            {
                MessageBox.Show("Please enter your mail.", "Employee Details", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
            }*/
        }

        private void EmployeeDetails_Load(object sender, EventArgs e)
        {
            try
            {
                EmpDAO.loadCountry(cbBCountry);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbBCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbBCountry.SelectedItem.ToString().Equals("Thailand"))
            {
                lbCity.Items.Add("Pattaya");
                lbCity.Items.Add("ChiangMai");
                lbCity.Items.Add("Bangkok");
                lbQuanlification.Items.Add("University");
                lbQuanlification.Items.Add("Master");
                lbQuanlification.Items.Add("Ph D");
            }
            else if (cbBCountry.SelectedItem.ToString().Equals("Vietnam"))
            {
                lbQuanlification.Items.Add("University");
                lbQuanlification.Items.Add("Master");
                lbQuanlification.Items.Add("Ph D");
            }
            else
            {
                lbCity.Items.Add("");
                lbQuanlification.Items.Add("");
            }
        }
    }
}
