﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1.Repository
{
    class EmployeeDetailsDAO
    {
        public void loadCountry(ComboBox comboBox)
        {
            string[] Country = { "--Selected--", "Vietnam", "Thailand" };
            foreach (var item in Country)
            {
                comboBox.Items.Add(item);
            }
            comboBox.SelectedIndex = 0;
        }

        /*public void initCity(ListBox listBox, ComboBox comboBox, ListBox listBox1)
        {
            if (comboBox.SelectedItem.ToString().Equals("Thailand"))
            {
                listBox.Items.Add("Pattaya");
                listBox.Items.Add("ChiangMai");
                listBox.Items.Add("Bangkok");
                listBox1.Items.Add("University");
                listBox1.Items.Add("Master");
                listBox1.Items.Add("Ph D");
            }
            else if (comboBox.SelectedItem.ToString().Equals("Vietnam"))
            {
                listBox1.Items.Add("University");
                listBox1.Items.Add("Master");
                listBox1.Items.Add("Ph D");
            }
        }*/
    }
}
