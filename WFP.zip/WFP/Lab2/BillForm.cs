﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Lab2
{
    public partial class BillForm : Form
    {
        public BillForm()
        {
            InitializeComponent();

            billDAO.initCity(domainUpDown1);
            billDAO.initQuantity(numericUpDown1);
            billDAO.initListView(listView1);
        }

        Repository.BillDAO billDAO = new Repository.BillDAO();

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            try
            {
int total = 0;
            int price = int.Parse(txtPrice.Text);
            int qoh = int.Parse(numericUpDown1.Value.ToString());
            total = price * qoh;
            lblTotal.Text = total.ToString() + " USD";
            }
            catch (Exception)
            {
                MessageBox.Show("Enter a price ...");
            }
            
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                /*if (!Regex.IsMatch(txtPID.Text,"^[P][0-9]{3}$"))
                {
                    MessageBox.Show("Invalid");
                    txtPID.Focus();
                    return;
                }
                else
                {*/
                    billDAO.createBill(listView1, txtBCode, dateTimePicker1, txtCName, domainUpDown1, txtPName, numericUpDown1, txtPrice);
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtPID_Validating(object sender, CancelEventArgs e)
        {
            if (!Regex.IsMatch(txtPID.Text, "^[P][0-9]{3}$"))
            {
                MessageBox.Show("Invalid");
                txtPID.Focus();
                return;
            }  
        }
    }
}
