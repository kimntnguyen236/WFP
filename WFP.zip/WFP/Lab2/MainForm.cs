﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Lab2.Repository;

namespace Lab2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            init.initProgressbar(progressBar1);
            initTimer();
        }
        InitControls init = new InitControls();

        public void initTimer()
        {
            Timer timer = new Timer();
            timer.Enabled = true;
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lbTimer.Text = "Timer's: " + DateTime.Now.ToLongTimeString()+ 
                "\n" + "Today's: " + DateTime.Now.ToShortDateString();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            splitContainer1.Panel2.Controls.Clear();
            if (treeView1.Nodes[0].Nodes[0].Nodes[0].IsSelected)
            {
                CustomerForm customerForm = new CustomerForm();

                customerForm.TopLevel = false;
                customerForm.Visible = true ;

                splitContainer1.Panel2.Controls.Add(customerForm);
            }
            else if (treeView1.Nodes[0].Nodes[1].Nodes[0].IsSelected)
            {
                BillForm bill = new BillForm();

                bill.TopLevel = false;
                bill.Visible = true;

                splitContainer1.Panel2.Controls.Add(bill);
            }
        }
    }
}
