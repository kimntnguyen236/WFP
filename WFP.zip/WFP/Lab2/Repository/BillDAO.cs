﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace Lab2.Repository
{
    class BillDAO
    {
        public void initCity(DomainUpDown domainUpDown)
        {
            List<string> cList = new List<string> {"Ha Noi","Da Nang","Sai Gon","Can Tho" };
            domainUpDown.Text = "--- Selected ---";
            domainUpDown.Items.AddRange(cList);
        }

        public void initQuantity(NumericUpDown numericUpDown)
        {
            numericUpDown.Minimum = 0;
            numericUpDown.Maximum = 20;
            numericUpDown.Increment = 1;
        }

        public void initListView(ListView listView)
        {
            listView.View = View.Details;
            listView.GridLines = true;
            listView.Columns.Add("Bill Code");
            listView.Columns.Add("Bill Dated");
            listView.Columns.Add("Customer Name");
            listView.Columns.Add("Location");
            listView.Columns.Add("Product Name");
            listView.Columns.Add("Quantity");
            listView.Columns.Add("Unit Price");
        }

        public void createBill(ListView listView, TextBox textBox, DateTimePicker dateTimePicker,TextBox textBox1,DomainUpDown domainUpDown, TextBox textBox2, NumericUpDown numericUpDown, TextBox textBox3)
        {
            string[] bList = {textBox.Text, dateTimePicker.Text,
                textBox1.Text ,domainUpDown.Text,
                textBox2.Text,numericUpDown.Value.ToString(),
                textBox3.Text };

            listView.Items.Add(new ListViewItem(bList));
            MessageBox.Show("Congratulation !!!");
        }
    }
}
