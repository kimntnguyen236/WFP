﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;
namespace Lab2.Repository
{
    class InitControls
    {
        public void initProgressbar(ProgressBar pB)
        {
            pB.Minimum = 0;
            pB.Maximum = 100;
            for (int i = pB.Minimum; i <= pB.Maximum; i++)
            {
                pB.Value = i;
            }
        }

        
    }
}
