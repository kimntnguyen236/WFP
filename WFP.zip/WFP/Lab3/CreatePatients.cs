﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;

namespace Lab3
{
    public partial class CreatePatients : Form
    {
        public CreatePatients()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PrintPreviewDialog printPreview = new PrintPreviewDialog();
            PrintDocument printDocument = new PrintDocument();
            printDocument.PrintPage += PrintDocument_PrintPage;
            printPreview.Document = printDocument;
            printPreview.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            graphics.DrawString(textBox1.Text.ToString(), new Font("Arial", 14), Brushes.Blue, 100,100);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Text file|*.txt|All file|*.*"; // * là kí tự bất kì
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFile.FileName))
                {
                    textBox1.Text = sr.ReadToEnd();
                    sr.Close();
                }
            }
            MessageBox.Show("Completed! ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Text file|*.txt|All file|*.*"; // * là kí tự bất kì
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(saveFile.FileName))
                {
                    sw.WriteLine(textBox1.Text);
                    sw.Flush();
                    sw.Close();
                }
            }
            MessageBox.Show("Completed! ");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.MinSize = 10;
            fontDialog.MaxSize = 60;
            fontDialog.Font = new Font("Arial", 10);
            fontDialog.ShowDialog();
            textBox1.Font = fontDialog.Font;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            colorDialog.Color = Color.Blue;
            colorDialog.FullOpen = true;
            colorDialog.ShowDialog();
            textBox1.ForeColor = colorDialog.Color; // gắn vào màu text trong textBox
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
