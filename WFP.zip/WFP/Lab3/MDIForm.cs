﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class MDIForm : Form
    {
        public MDIForm()
        {
            InitializeComponent();
        }

        
        public void showLogin()
        {
            Login login = new Login();
            login.ShowDialog();
        }

        private void MDIForm_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.IsMdiContainer = true;

            initControls();
            showLogin();
        }

        private void initControls()
        {
            lblDate.Text = "Today's: " + DateTime.Now.ToLongDateString();
            proBar.Value = 99;
        }
        private void patientToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void redTools_Click(object sender, EventArgs e)
        {
            menuStrip2.BackColor = Color.Red;
            toolStrip1.BackColor = Color.Red;
        }

        private void YellowTools_Click(object sender, EventArgs e)
        {
            menuStrip2.BackColor = Color.Blue;
            toolStrip1.BackColor = Color.Red;
        }

        private void greenTools_Click(object sender, EventArgs e)
        {
            menuStrip2.BackColor = Color.Green;
            toolStrip1.BackColor = Color.Blue;
        }

        private void addPatient_Click(object sender, EventArgs e)
        {
            CreatePatients patients = new CreatePatients();
           patients.MdiParent = this;
            patients.Show();
        }

        BMI bmi;
        private void initBMI(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            bmi.MdiParent = this;
            bmi.Show();
        }

        private void btnBMI_Click(object sender, EventArgs e)
        {
            bmi = new BMI();
            // bmi.MdiParent = this;
            // bmi.Show();
            initBMI(bmi);
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

    }
}
