﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3.Repository
{
    class LoginDAO
    {
        public bool CheckLogin(TextBox name, TextBox pass)
        {
            if (name.Text.Equals("FPT") && pass.Text.Equals("123"))
            {
                new MDIForm().Show();
                return true;
            }
            if (string.IsNullOrEmpty(name.Text))
            {
                MessageBox.Show("User not found....", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                name.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(pass.Text))
            {
                MessageBox.Show("Invalid password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                name.Focus();
                return false;
            }
            else
            {
                MessageBox.Show("Invalid username and passsword !!!");
            }

            return true;
        }
    }
}
