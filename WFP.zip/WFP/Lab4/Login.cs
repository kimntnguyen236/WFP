﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab4.Repository;
namespace Lab4
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            dao.setConnect();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        AccountDAO dao = new AccountDAO();
        private void btnSignin_Click(object sender, EventArgs e)
        {
            if (dao.checkLogin(txtNo.Text,txtPin.Text)==true)
            {
                this.Hide();
                ATM atm = new ATM();
                atm.sendMsgNo(txtNo.Text);
                atm.Show();
            }

        }

        private void lblOpenAcc_Click(object sender, EventArgs e)
        {
            this.Hide();
            ATM atm = new ATM();
            atm.sendMsgNo(txtNo.Text);
            atm.Show();
        }

        private void lblOpenAcc_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            new OpenAccount().Show();
        }
    }
}
