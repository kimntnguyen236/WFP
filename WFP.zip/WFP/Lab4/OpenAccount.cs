﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab4.Models;
using Lab4.Repository;

namespace Lab4
{
    public partial class OpenAccount : Form
    {
        public OpenAccount()
        {
            InitializeComponent();
            dao.setConnect();
        }

        AccountDAO dao = new AccountDAO();
        Login lg = new Login();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                Account account = new Account
                {
                    AccountNo = txtNo.Text,
                    AccountName = txtName.Text,
                    Address = txtAddress.Text,
                    PinCode = txtPin.Text,
                    Balance = float.Parse(txtBalance.Text)
                };
                dao.openAccount(account);
                this.Hide();
                lg.Show();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
