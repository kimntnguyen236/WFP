﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Lab4.Models;
using System.Windows.Forms;

namespace Lab4.Repository
{
    class AccountDAO
    {
        private SqlConnection sqlConnection;
        private SqlCommand sqlCommand;
        private SqlDataAdapter sqlDataAdapter;
        private DataSet ds;
        public void setConnect()
        {
            // string uri = "server=.;database=Sem3DB;uid=sa;pwd=123";
            string uri = "server=.;database=Sem3DB;Trusted_Connection=true";
            sqlConnection = new SqlConnection(uri);
        }
        public void openAccount(Models.Account account)
        {
            string sql = "INSERT Account VALUES(@no, @name, @address, @pin, @balance) ";
            sqlCommand = new SqlCommand(sql, sqlConnection);
            sqlCommand.Parameters.AddWithValue("@no", account.AccountNo);
            sqlCommand.Parameters.AddWithValue("@name", account.AccountName);
            sqlCommand.Parameters.AddWithValue("@address", account.Address);
            sqlCommand.Parameters.AddWithValue("@pin", account.PinCode);
            sqlCommand.Parameters.AddWithValue("@balance", account.Balance);
            try
            {
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                MessageBox.Show("Congratulation !");
            }
            catch (Exception)
            {
                MessageBox.Show("Error");
            }
            sqlConnection.Close();

        }
        public bool checkLogin(string accountNo, string pinCode)
        {
            string sql = "SELECT * FROM Account WHERE AccountNo='" + accountNo + "' AND Pincode='" + pinCode + "'";
            sqlDataAdapter = new SqlDataAdapter(sql, sqlConnection);
            ds = new DataSet();
            sqlDataAdapter.Fill(ds, "Account");
            if (ds.Tables["Account"].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void checkBalance(TextBox balance, Label lblNo)
        {
            string sql = "SELECT * FROM Account Where AccountNo='" + lblNo.Text + "'";
            sqlDataAdapter = new SqlDataAdapter(sql, sqlConnection);
            ds = new DataSet();
            sqlDataAdapter.Fill(ds, "Account");
            foreach (DataRow row in ds.Tables["Account"].Rows)
            {
                if (row["AccountNo"].ToString() == lblNo.Text)
                {
                    balance.Text = row["Balance"].ToString();
                }
            }
        }
        public void deposit()
        {

        }
        public void withdraw()
        {

        }
    }
}
