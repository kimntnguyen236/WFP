﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class BookForm : Form
    {
        public BookForm()
        {
            InitializeComponent();
        }

        DAL_DataAccessLayer.BookDAO dao = new DAL_DataAccessLayer.BookDAO();
        private void loadData()
        {
            dao.loadCombo(comboBoxGenre);
            dao.getBook(dataGridView1);
        }

        private void comboBoxGenre_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BookForm_Load(object sender, EventArgs e)
        {
            dao.connection();
            loadData();
            dao.bindingControls(txtISBN, txtTitle, comboBoxGenre, txtEdition, dataGridView1);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Regex.IsMatch(txtISBN.Text,"^[B][0-9]{3}$"))
                {
                    MessageBox.Show("ISBN invalid. (Bxxx - x: digit)");
                    txtISBN.Focus();
                    return;
                }
                else if (!Regex.IsMatch(txtTitle.Text, "^[A-Za-z0-9 ]{1,50}$"))
                {
                    MessageBox.Show("Title invalid. (No special character [1-50])");
                    txtTitle.Focus();
                    return;
                }
                else if (!Regex.IsMatch(txtEdition.Text, "^[0-9]{1,3}$"))
                {
                    MessageBox.Show("Edition invalid. Only number [1-3]");
                    txtEdition.Focus();
                    return;
                }
                else
                {
                Models.Book book = new Models.Book
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Edition = int.Parse(txtEdition.Text),
                    Id = int.Parse(comboBoxGenre.Text),
                };
                dao.addBook(book);
                MessageBox.Show("Congratulation!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            dao.bindingControls(txtISBN, txtTitle, comboBoxGenre, txtEdition, dataGridView1);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Models.Book book = new Models.Book
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Edition = int.Parse(txtEdition.Text),
                    Id = int.Parse(comboBoxGenre.Text),
                    
                };
                dao.updateBook(book);
                MessageBox.Show("Update successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            dao.searchBook(textBox3, dataGridView1);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Models.Book book = new Models.Book
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Edition = int.Parse(txtEdition.Text),
                    Id = int.Parse(comboBoxGenre.Text),
                };
                dao.deleteBook(book);
                MessageBox.Show("Deleted successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
                
        }
    }
}
