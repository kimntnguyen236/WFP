﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab5.DAL_DataAccessLayer
{
    class BookDAO
    {
        private SqlConnection sqlConnection;
        private SqlDataAdapter dataAdapter;
        private SqlCommand command;
        private DataSet dataSet;

        public SqlConnection connection()
        {
            string str = "server=.;database=Lab5DB;uid=sa;pwd=123";
            sqlConnection = new SqlConnection(str);
            return sqlConnection;
        }
        public void loadCombo(ComboBox comboBox)
        {
            string query = "SELECT * FROM Genre";
            dataAdapter = new SqlDataAdapter(query, sqlConnection);
            dataSet = new DataSet();
            dataAdapter.Fill(dataSet, "Genre");

            comboBox.DataSource = dataSet.Tables["Genre"];
            //comboBox.DisplayMember = "GenreName"; // DisplayName dùng cho cột không khóa
            comboBox.ValueMember = "Id"; // ValueMember dùng cho cột khóa
        }
        public void addBook(Models.Book book) // một tham số : object, nhiều tham số: ....
        {
            string query = "INSERT Book VALUES(@isbn,@title,@edition,@id)";
            command = new SqlCommand(query, sqlConnection);
            command.Parameters.AddWithValue("@isbn",book.ISBN);
            command.Parameters.AddWithValue("@title", book.Title);
            command.Parameters.AddWithValue("@edition", book.Edition);
            command.Parameters.AddWithValue("@id", book.Id);
            sqlConnection.Open();
            command.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void getBook(DataGridView gridView)
        {
            string query = "SELECT * FROM Book";
            dataAdapter = new SqlDataAdapter(query, sqlConnection);
            dataSet = new DataSet();
            dataAdapter.Fill(dataSet, "Book");

            gridView.DataSource = dataSet.Tables["Book"];
        }
        public void bindingControls(TextBox txtISBN, TextBox txtTitle, ComboBox comboBox,TextBox txtEdition, DataGridView gridView)
        {
            txtISBN.Text = gridView.CurrentRow.Cells[0].Value.ToString();
            txtTitle.Text = gridView.CurrentRow.Cells[1].Value.ToString();
            comboBox.Text = gridView.CurrentRow.Cells[3].Value.ToString();
            txtEdition.Text = gridView.CurrentRow.Cells[2].Value.ToString();
        }
        public void updateBook(Models.Book book) // một tham số : object, nhiều tham số: ....
        {
            string query = "UPDATE Book SET Title=@title,Edition= @edition,Id=@id WHERE ISBN = @isbn";
            command = new SqlCommand(query, sqlConnection);
            command.Parameters.AddWithValue("@title", book.Title);
            command.Parameters.AddWithValue("@edition", book.Edition);
            command.Parameters.AddWithValue("@id", book.Id);
            command.Parameters.AddWithValue("@isbn", book.ISBN);
            sqlConnection.Open();
            command.ExecuteNonQuery();
            sqlConnection.Close();
        }
        public void searchBook(TextBox textBox,DataGridView dataGridView)
        {
            string query = "SELECT * FROM Book WHERE Title LIKE '%"+textBox.Text+"%'";
            dataAdapter = new SqlDataAdapter(query, sqlConnection);
            dataSet = new DataSet();
            dataAdapter.Fill(dataSet, "Book");
            dataGridView.DataSource = dataSet.Tables["Book"];
        }
        public void deleteBook(Models.Book book) // một tham số : object, nhiều tham số: ....
        {
            string query = "DELETE FROM Book WHERE ISBN = @isbn";
            command = new SqlCommand(query, sqlConnection);
            command.Parameters.AddWithValue("@isbn", book.ISBN);
            sqlConnection.Open();
            command.ExecuteNonQuery();
            sqlConnection.Close();
        }
    }
}
