﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace Lab5.DAL_DataAccessLayer
{
    class GenreDAO
    {
        private SqlConnection sqlConnection;
        private SqlDataAdapter dataAdapter;
        private SqlCommand command;
        private DataSet dataSet;

        public SqlConnection connection()
        {
            string str = "server=.;database=Lab5DB;uid=sa;pwd=123";
            sqlConnection = new SqlConnection(str);
            return sqlConnection;
        }
    }
}
