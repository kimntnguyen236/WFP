﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class MdiForm : Form
    {
        public MdiForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.IsMdiContainer = true;
        }

        private void menuGenre_Click(object sender, EventArgs e)
        {
            genreForm = new GenreForm();
            initBookForm(genreForm);

            //GenreForm genre = new GenreForm();
            //genre.MdiParent = this;
            //genre.Show();
        }

        private void menuCreate_Click(object sender, EventArgs e)
        {
            bookForm = new BookForm();
            initBookForm(bookForm);

            //BookForm book = new BookForm();
            //book.MdiParent = this;
            //book.Show();
        }

        // cố định 1 form duy nhất
        BookForm bookForm;
        private void initBookForm(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            bookForm.MdiParent = this;
            bookForm.Show();
        }

        GenreForm genreForm;
        private void initGenreForm(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            genreForm.MdiParent = this;
            genreForm.Show();
        }
    }
}
