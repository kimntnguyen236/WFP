﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; // datatable - dataset
using System.Data.SqlClient; // sql 
using System.Windows.Forms; // cac control windows form

namespace Lab6.DAL
{
    class CustomerDAO
    {
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlCommand command;
        private DataSet ds;

        public BindingSource bs;

        public SqlConnection setConnect()
        {
            string str = "server=.;database=Sem3DB;uid=sa;pwd=123";
            connection = new SqlConnection(str);
            return connection;
        }
        public void loadData(DataGridView gridView,TextBox txtID,TextBox txtName,TextBox txtAddress, TextBox txtPhone)
        {
            //string query = "SELECT * FROM Customer";
            command = new SqlCommand("spGetCustomers", connection);
            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
            bs = new BindingSource();
            bs.DataSource = ds.Tables["Customer"];
            gridView.DataSource = bs.DataSource;

            // Complex Binding
            gridView.DataSource = bs;
            //Simple Binding
            txtID.DataBindings.Clear();
            txtID.DataBindings.Add("Text", bs, "CustomerID");
            txtName.DataBindings.Clear();
            txtName.DataBindings.Add("Text", bs, "CustomerName");
            txtAddress.DataBindings.Clear();
            txtAddress.DataBindings.Add("Text", bs, "Address");
            txtPhone.DataBindings.Clear();
            txtPhone.DataBindings.Add("Text", bs, "Phone");
        }
        public void postCustomer(Models.Customer customer)
        {
            command = new SqlCommand("spAddstomer", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@cusID",customer.CustomerID);
            command.Parameters.AddWithValue("@cusName", customer.CustomerName);
            command.Parameters.AddWithValue("@address", customer.Address);
            command.Parameters.AddWithValue("@phone", customer.Phone);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds,"spAddstomer");
        }
        public void deleteCustomer(TextBox txtID)
        {
            command = new SqlCommand("spDelCustomer", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@cusID", txtID.Text);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
        }
    }
}
