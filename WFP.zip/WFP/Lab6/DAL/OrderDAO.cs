﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data; // datatable - dataset
using System.Data.SqlClient; // sql 
using System.Windows.Forms; // cac control windows form

namespace Lab6.DAL
{
    class OrderDAO
    {
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlDataAdapter adapter1;
        private SqlCommand command;
        private DataSet ds;

        public BindingSource bs;
        public SqlConnection setConnect()
        {
            string str = "server=.;database=Sem3DB;uid=sa;pwd=123";
            connection = new SqlConnection(str);
            return connection;
        }

        public void bindingMasterDetails(DataGridView dgCustomer, DataGridView dgOrder)
        {
            string queryCus = "SELECT * FROM Customer";
            string queryOrder = "SELECT * FROM Order";
            command = new SqlCommand(queryCus, connection);
            adapter = new SqlDataAdapter(queryOrder, connection);
            adapter1 = new SqlDataAdapter(queryCus, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
            adapter1.Fill(ds, "Order");

            ds.Relations.Add("CusOrder", ds.Tables["Customer"].Columns["CustomerID"],
                ds.Tables["Order"].Columns["CustomerID"], true);

            var bsCus = new BindingSource();
            var bsOrder = new BindingSource();

            bsCus.DataSource = ds.Tables["Customer"];
            dgCustomer.DataSource = bsCus;

            bsOrder.DataSource = bsCus;
            bsOrder.DataMember = "CusOrder";

            dgOrder.DataSource = bsOrder;
        }
    }
}
