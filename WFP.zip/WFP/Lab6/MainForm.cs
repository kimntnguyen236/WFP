﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            setReadOnlyControls();
        }

        private void setReadOnlyControls() {
            btnCreate.Enabled = false;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            txtCusID.ReadOnly = true;
            txtCusName.ReadOnly = true;
            txtAddress.ReadOnly = true;
            txtPhone.ReadOnly = true;
        }

        private void setControls()
        {
            btnCreate.Enabled = true;
            btnUpdate.Enabled = true;
            btnDelete.Enabled = true;
            txtCusID.ReadOnly = false;
            txtCusName.ReadOnly = false;
            txtAddress.ReadOnly = false;
            txtPhone.ReadOnly = false;
        }


        DAL.CustomerDAO cusDAO = new DAL.CustomerDAO();
        private void MainForm_Load(object sender, EventArgs e)
        {

            btnPrevious.Enabled = false;
            btnFirst.Enabled = false;
            try
            {
                cusDAO.setConnect();
                cusDAO.loadData(gvCustomer,txtCusID,txtCusName,txtAddress,txtPhone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void gvCustomer_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                cusDAO.setConnect();
                cusDAO.loadData(gvCustomer, txtCusID, txtCusName, txtAddress, txtPhone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cusDAO.bs.MoveFirst();
        }
        private void btnNext_Click(object sender, EventArgs e)
        {
            cusDAO.bs.MoveNext();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            cusDAO.bs.MovePrevious();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            cusDAO.bs.MoveLast();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            setControls();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                Models.Customer customer = new Models.Customer {
                    CustomerID = txtCusID.Text,
                    CustomerName = txtCusName.Text,
                    Address = txtAddress.Text,
                    Phone = txtPhone.Text,
                };
                cusDAO.postCustomer(customer);
                MessageBox.Show("Congratulation!");
                cusDAO.loadData(gvCustomer, txtCusID, txtCusName, txtAddress, txtPhone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                cusDAO.deleteCustomer(txtCusID);
                MessageBox.Show("Congratulation!");
                cusDAO.loadData(gvCustomer, txtCusID, txtCusName, txtAddress, txtPhone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
