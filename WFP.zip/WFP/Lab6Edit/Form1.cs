﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Lab6Edit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            setConnect();
            loadData();
        }

        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlCommand command;
        private DataSet ds;

        public BindingSource bs;

        public SqlConnection setConnect()
        {
            string str = "server=.;database=Sem3DB;uid=sa;pwd=123";
            connection = new SqlConnection(str);
            return connection;
        }

        public void loadData()
        {
            string query = "SELECT * FROM Customer";
            command = new SqlCommand(query, connection);
            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
            bs = new BindingSource();
            bs.DataSource = ds.Tables["Customer"];
            gvCustomer.DataSource = bs.DataSource;

            // Complex Binding
            gvCustomer.DataSource = bs;
            //Simple Binding
            txtCusID.DataBindings.Clear();
            txtCusID.DataBindings.Add("Text", bs, "CustomerID");
            txtCusName.DataBindings.Clear();
            txtCusName.DataBindings.Add("Text", bs, "CustomerName");
            txtAddress.DataBindings.Clear();
            txtAddress.DataBindings.Add("Text", bs, "Address");
            txtPhone.DataBindings.Clear();
            txtPhone.DataBindings.Add("Text", bs, "Phone");
        }
        public void postCustomer()
        {
            string query = "INSERT Customer VALUES (@cusID,@cusName,@address,@phone)";
            command = new SqlCommand(query, connection);
            //command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@cusID", txtCusID.Text);
            command.Parameters.AddWithValue("@cusName", txtCusName.Text);
            command.Parameters.AddWithValue("@address", txtAddress.Text);
            command.Parameters.AddWithValue("@phone", txtPhone.Text);
            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
            var bsPro = new BindingSource();

            bsPro.DataSource = ds.Tables["Products"];

            gvCustomer.DataSource = bsPro;
        }
        public void deleteCustomer()
        {
            string query = "DELETE FROM Customer WHERE CustomerID = @cusID";
            command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@cusID", txtCusID);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                postCustomer();
                MessageBox.Show("Congratulation!");
                loadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                deleteCustomer();
                MessageBox.Show("Congratulation!");
                loadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void gvCustomer_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                //setConnect();
                loadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            bs.MoveFirst();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            bs.MovePrevious();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            bs.MoveNext();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            bs.MoveLast();
        }
        public void updateCus()
        {
            string query = "UPDATE Customer SET CustomerName=@cusName,Address=@address,Phone=@phone WHERE CustomerID = @cusID";
            command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@cusName", txtCusName);
            command.Parameters.AddWithValue("@address", txtAddress);
            command.Parameters.AddWithValue("@phone", txtPhone);
            command.Parameters.AddWithValue("@cusID", txtCusID);
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                updateCus();
                MessageBox.Show("Update successfully!");
                loadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void searchbyName()
        {
            string query = "SELECT * FROM Customer WHERE CustomerName LIKE '%" + txtCusName + "%'";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
            gvCustomer.DataSource = ds.Tables["Customer"];
        }

        private void button5_Click(object sender, EventArgs e)
        {
            searchbyName();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            searchbyName();
        }
    }
}
