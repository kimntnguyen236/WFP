﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace Lab7
{
    public partial class BookManage : Form
    {
        public BookManage()
        {
            InitializeComponent();
            toolTip1.SetToolTip(txtID, "Enter a ID ...");
            GetBooks();
        }

        private SqlConnection conn;
        private SqlDataAdapter dataAdapter;
        private DataSet ds;

        private void GetBooks()
        {
            string uri = "server=.;database=Sem3DB;uid=sa;pwd=123";
            conn = new SqlConnection(uri);

            dataAdapter = new SqlDataAdapter("SELECT * FROM Book", conn);
            ds = new DataSet();
            dataAdapter.Fill(ds, "Book");
            dataGridView1.DataSource = ds.Tables["Book"];
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            var ppd = new PrintPreviewDialog();
            var pd = new PrintDocument();
            if (ds.Tables["Book"].Rows.Count > 0)
            {
                pd.PrintPage += Pd_PrintPage;
                ppd.Document = pd;
                ppd.Show();
            }
        }

        private void Pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            int row = dataGridView1.SelectedCells[0].RowIndex; // tra ve vi tri hien hanh cua dong dang chon

            // nối chuỗi
            var sb = new StringBuilder();
            int id = int.Parse(dataGridView1.Rows[row].Cells[0].Value.ToString());
            string title = dataGridView1.Rows[row].Cells[1].Value.ToString();
            string author = dataGridView1.Rows[row].Cells[2].Value.ToString();
            int edition = int.Parse(dataGridView1.Rows[row].Cells[3].Value.ToString());
            string dated = dataGridView1.Rows[row].Cells[4].Value.ToString();
            sb.AppendLine("--- Book Detail's ---");
            sb.AppendLine("Book ID: " + id);
            sb.AppendLine("Book Title: " + title);
            sb.AppendLine("Author: " + author);
            sb.AppendLine("Edition: " + edition);
            sb.AppendLine("Publish Dated: " + dated);
            sb.AppendLine("----------------------");

            // graphics không có hàm dựng
            Graphics graphics = e.Graphics;
            graphics.DrawString(sb.ToString(), new Font("Arial", 12),Brushes.Red,100,100);

        }
    }
}
