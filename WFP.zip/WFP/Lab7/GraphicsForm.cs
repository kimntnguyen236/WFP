﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class GraphicsForm : Form
    {
        public GraphicsForm()
        {
            InitializeComponent();
            this.graphics = label1.CreateGraphics();
        }

        Graphics graphics;
        private void btnLine_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            graphics.DrawLine(new Pen(Color.Red),50,50,190,190);
        }

        private void btnCircle_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            //graphics.DrawEllipse(new Pen(Color.HotPink), 90, 90, 290, 290);
            graphics.FillEllipse(Brushes.Red,120,70,290,290);
        }

        private void btnRectange_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            graphics.DrawRectangle(new Pen(Color.Green), 120, 70, 290,290);
            //graphics.FillRectangle(Brushes.Red, 120, 70, 290, 290);
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            graphics.DrawImage(Image.FromFile("twitter_80px.png"), 120, 70, 290, 290);
        }
    }
}
