﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Lab7
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.HelpButton = true;
            GetBooks();
        }

        private void GetBooks()
        {
            string uri = "server=.;database=Sem3DB;uid=sa;pwd=123";
            var conn = new SqlConnection(uri);

            var dataAdapter = new SqlDataAdapter("SELECT * FROM Book",conn);
            var ds = new DataSet();
            dataAdapter.Fill(ds, "Book");
            var cr = new CrystalReport1();
            // sap xep 
            var dv = new DataView();
            // lay Dataset rang buoc Dataview 
            dv = ds.Tables["Book"].DefaultView;
            dv.Sort = "Title DESC";
            cr.SetDataSource(dv);
            //cr.SetDataSource(ds);
            crystalReportViewer1.ReportSource = cr;
        }
    }
}
