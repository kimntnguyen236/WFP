﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            searchByCode();
        }
        private void initTabControls()
        {
            // giấu 2 tabpage theo tên
            tabControl1.TabPages.Remove(tabAddStore);
            tabControl1.TabPages.Remove(tabSearch);

            // giấu 2 tabpage theo chỉ mục
            //tabControl1.TabPages.RemoveAt(1);
            //tabControl1.TabPages.RemoveAt(2);
        }
        private void initTabPages()
        {
            // hiển thị 2 tabpage theo tên
            tabControl1.TabPages.Insert(1, tabAddStore);
            tabControl1.TabPages.Insert(2, tabSearch);
            tabControl1.SelectedTab = tabAddStore;
        }
        private void initNotifyIcon()
        {
            notifyIcon1.Visible = true;
            notifyIcon1.BalloonTipText = "Message";
            notifyIcon1.BalloonTipTitle = "The SMS is running ...";
            notifyIcon1.ShowBalloonTip(7);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            initTabControls();
            initNotifyIcon();
            setConnect();
            loadStore();
        }

        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataSet ds;
        private SqlConnection setConnect()
        {
            string str = "server=.; database = Sem3DB; uid =sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }
        private void checkLogin()
        {
            string query = "SELECT * FROM Employee WHERE UserName = '" + txtUserName.Text + "' AND Password = '" + txtPassword.Text + "'";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Employee");
            if (ds.Tables["Employee"].Rows.Count >0)
            {
                MessageBox.Show("Hi "+txtUserName.Text +" !");
                initTabPages();
            }
            else
            {
                MessageBox.Show("Fail...");
            }
        }
        private void loadStore()
        {
            string query = "SELECT * FROM Store";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Store");
            dataGridView1.DataSource = ds.Tables["Store"];
        }
        private void createStore()
        {
            string query = "INSERT Store VALUES (@code,@name,@phone,@location,@num)";
            var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@code", txtCode.Text);
            command.Parameters.AddWithValue("@name", txtSName.Text);
            command.Parameters.AddWithValue("@phone", txtSPhone.Text);
            command.Parameters.AddWithValue("@location", txtSLocation.Text);
            command.Parameters.AddWithValue("@num", trackBar1.Value);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Store");
        }
        private void updateStore()
        {
            int row = dataGridView1.CurrentRow.Index;
            string code = dataGridView1.Rows[row].Cells[0].Value.ToString();
            string name = dataGridView1.Rows[row].Cells[1].Value.ToString();
            string phone = dataGridView1.Rows[row].Cells[2].Value.ToString();
            string location = dataGridView1.Rows[row].Cells[3].Value.ToString();
            int num = int.Parse(dataGridView1.Rows[row].Cells[4].Value.ToString());

            string query = "UPDATE Store SET StoreName= @name,PhoneNumber=@phone,Location=@location,EmployeeNumber =@num WHERE StoreCode = @code";
            var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@name", name);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@location", location);
            command.Parameters.AddWithValue("@num", num);
            command.Parameters.AddWithValue("@code", code);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Store");
        }
        private void deleteStore()
        {
            int row = dataGridView1.CurrentRow.Index;
            string code = dataGridView1.Rows[row].Cells[0].Value.ToString();

            string query = "DELETE FROM Store WHERE StoreCode = @code";
            var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@code", code);

            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Store");
        }
        private void btnSignin_Click(object sender, EventArgs e)
        {
            try
            {
                checkLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtCode.Text))
                {
                    MessageBox.Show("Store code is required ...");
                    txtCode.Focus();
                }
                else
                {
                    createStore();
                    MessageBox.Show("Congratulation!");
                    loadStore();
                    txtCode.Clear();
                    txtSName.Clear();
                    txtSPhone.Clear();
                    txtSLocation.Clear();
                    txtnum.Hide();
                    trackBar1.Value = trackBar1.Minimum;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            txtnum.Text = trackBar1.Value.ToString();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                updateStore();
                MessageBox.Show("Success!");
                loadStore();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                deleteStore();
                loadStore();
                MessageBox.Show("Success!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void searchByCode()
        {
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                // equals là tìm tuyệt đối
                var list = from v
                           in db.Stores
                           where v.StoreCode.Contains(txtSearch.Text)
                           select v;
                dataGridView1.DataSource = list.ToList(); // nếu var -> list thì không cần tolist()
            }
        }
        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            searchByCode();
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
