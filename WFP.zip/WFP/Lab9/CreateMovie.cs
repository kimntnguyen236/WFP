﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class CreateMovie : Form
    {
        public CreateMovie()
        {
            InitializeComponent();
            GetGenre();
        }
        private void GetGenre()
        {
            string[] genres = {"Action","Comedy","Horror","Cartoon"};
            foreach (var item in genres)
            {
                cbxGenre.Items.Add(item.ToString());
            }
        }

        // Sem3DBEntities DB = new Sem3DBEntities();
        private void btnCreate_Click(object sender, EventArgs e)
        {
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                //Movie movie = (from v
                //            in db.Movies
                //            where v.MovieName==txtName.Text
                //            select v).SingleOrDefault();

                Movie movie = db.Movies.SingleOrDefault(m=>m.MovieName.Equals(txtName.Text));
                if (movie==null)
                {
                    // nếu không kiểm tra trùng thì không cần if else
                    Movie mv = new Movie
                    {
                        MovieName = txtName.Text,
                        Genre = cbxGenre.SelectedItem.ToString(),
                        Director = txtDirector.Text,
                        ReleaseOfYear = txtYear.Value,
                    };
                    db.Movies.Add(mv);
                    db.SaveChanges();
                    MessageBox.Show("Add movie completed successfully.");
                }
                else
                {
                    MessageBox.Show("Has existed...");
                    txtName.Focus();
                }
            }
        }
    }
}
