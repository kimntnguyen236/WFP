﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Lab9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void processObject()
        {
            List<int> list = new List<int> {5,10,8,15,30,6,35,50,22};
            var result = (from n
                         in list
                         where n > 15
                         orderby n descending
                         select n).ToList();
            listBox1.Items.Clear();
            foreach (var item in result)
            {
                listBox1.Items.Add(item.ToString());
            }
        }
        private void btnObject_Click(object sender, EventArgs e)
        {
            try
            {
                processObject();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void processXML()
        {
            XElement element = XElement.Load("Employees.xml");
            var result = from e
                         in element.Descendants("Employee")
                         select e;
            listBox1.Items.Clear();
            foreach (var item in result)
            {
                listBox1.Items.Add(item.Element("Code").Value.ToString()+"\t\t"+ item.Element("Name").Value.ToString() + "\t\t" + item.Element("Salary").Value.ToString());
            }
        }
        private void btnXML_Click(object sender, EventArgs e)
        {
            try
            {
                processXML();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
