﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class MainForm_MDI : Form
    {
        public MainForm_MDI()
        {
            InitializeComponent();
            initForm();
        }
        private void initForm()
        {
            this.WindowState = FormWindowState.Maximized; // full screen
            this.IsMdiContainer = true; // tạo bộ chứa
        }

        private void menuItemCreate_Click(object sender, EventArgs e)
        {
            create = new CreateMovie();
            initCreateMovie(create);
            //CreateMovie createMovie = new CreateMovie();
            //createMovie.MdiParent = this;
            //createMovie.Show();
        }

        private void menuItemSearch_Click(object sender, EventArgs e)
        {
            edit = new ManageMovie();
            initManageMovie(edit);
            //ManageMovie manageMovie = new ManageMovie();
            //manageMovie.MdiParent = this;
            //manageMovie.Show();
        }

        // cố định 1 form duy nhất
        CreateMovie create;
        private void initCreateMovie(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            create.MdiParent = this;
            create.Show();
        }
        // cố định 1 form duy nhất
        ManageMovie edit;
        private void initManageMovie(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            edit.MdiParent = this;
            edit.Show();
        }
    }
}
