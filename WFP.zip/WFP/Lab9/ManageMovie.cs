﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class ManageMovie : Form
    {
        public ManageMovie()
        {
            InitializeComponent();
            searchByDirector();
        }

        private void searchByDirector()
        {
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                // equals là tìm tuyệt đối
                var list = from v
                           in db.Movies
                           where v.Director.Contains(txtSearch.Text)
                           select v;
                dataGridView1.DataSource = list.ToList(); // nếu var -> list thì không cần tolist()
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            searchByDirector();
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            searchByDirector();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            new MovieReport().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int row = dataGridView1.CurrentRow.Index;
            int id = int.Parse(dataGridView1.Rows[row].Cells[0].Value.ToString());
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                Movie res = (from v
                          in db.Movies
                          where v.MovieId == id
                          select v).SingleOrDefault();

                DialogResult message = MessageBox.Show("Are you sure?", "pls check ...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (message == DialogResult.OK)
                {
                    db.Movies.Remove(res);
                    db.SaveChanges();
                    searchByDirector();
                }
                else
                {
                    // no dothing
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int row = dataGridView1.CurrentRow.Index;
            int id = int.Parse(dataGridView1.Rows[row].Cells[0].Value.ToString());
            string name = dataGridView1.Rows[row].Cells[1].Value.ToString();
            string genre = dataGridView1.Rows[row].Cells[2].Value.ToString();
            string director = dataGridView1.Rows[row].Cells[3].Value.ToString();
            DateTime year = DateTime.Parse(dataGridView1.Rows[row].Cells[4].Value.ToString());
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                Movie movie = (from v
                          in db.Movies
                               where v.MovieId == id
                               select v).SingleOrDefault();

                DialogResult message = MessageBox.Show("Are you sure?", "pls check ...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (movie != null && message == DialogResult.OK)
                {
                    movie.MovieName = name;
                    movie.Genre = genre;
                    movie.Director = director;
                    movie.ReleaseOfYear = year;
                    db.SaveChanges();
                    searchByDirector();
                }
                else
                {
                    // no dothing
                }
            }
        }
        
    }
}
