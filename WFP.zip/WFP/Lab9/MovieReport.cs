﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class MovieReport : Form
    {
        public MovieReport()
        {
            InitializeComponent();
            GetMovie();
        }
        private void GetMovie()
        {
            using (Sem3DBEntities1 db = new Sem3DBEntities1())
            {
                var movieList = (from list
                                in db.Movies
                                select list);
                var cr = new CrystalReport2();
                cr.SetDataSource(movieList);
                crystalReportViewer1.ReportSource = cr;
            }
        }
    }
}
