﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace Lap1.DAL
{
    class CourseDAO
    {
        public void loadCourses(ComboBox comboBox)
        {
            string[] courseName = { "--Selectted--", "JavaScript", "C++","OOP"};
            foreach (var item in courseName)
            {
                comboBox.Items.Add(item);
            }
            comboBox.SelectedIndex = 0;
        }
        public void addImageList(ImageList imageList)
        {
            imageList.Images.Add(Image.FromFile(@"D:\AptechSem3\WFP\WFP\Lap1\Resources\1.png"));
            imageList.Images.Add(Image.FromFile(@"D:\AptechSem3\WFP\WFP\Lap1\Resources\2.png")); ;
            imageList.Images.Add(Image.FromFile(@"D:\AptechSem3\WFP\WFP\Lap1\Resources\92734361_543916549865668_8425964199611465728_n.png"));
        }
        public void bindingControls(ComboBox comboBox, TextBox duration, TextBox fee, PictureBox pictureBox, ImageList imageList)
        {
            if (comboBox.SelectedItem.ToString().Equals("Javacript"))
            {
                duration.Text = "2.5 months";
                fee.Text = "1.7 VND";
                pictureBox.Image = imageList.Images[0];
            }
            else if (comboBox.SelectedItem.ToString().Equals("C++"))
            {
                duration.Text = "3 months";
                fee.Text = "2.2 VND";
                pictureBox.Image = imageList.Images[1];
            }
            else if (comboBox.SelectedItem.ToString().Equals("OOP"))
            {
                duration.Text = "4.5 months";
                fee.Text = "3.5 VND";
                pictureBox.Image = imageList.Images[2];
            }
            else
            {
                //MessageBox.Show("Course name seleted. Pls....");
                duration.Text = "";
                fee.Text = "";
            }
        }
    }
}
