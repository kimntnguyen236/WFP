﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lap1.DAL;
namespace Lap1
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            controlsEnable();
        }
        private void controlsEnable()
        {
            txtDuration.ReadOnly = true;
            txtFee.ReadOnly = true;
        }
        CourseDAO  courseDAO= new CourseDAO();
        
        private void Register_Load(object sender, EventArgs e)
        {
            try
            {
                courseDAO.loadCourses(cbCName);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbCName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbCName.SelectedItem.ToString().Equals("JavaScript"))
            {
                txtDuration.Text = "2.5 months";
                txtFee.Text = "1700000 (VND)";
            }
            else if (cbCName.SelectedItem.ToString().Equals("C++"))
            {
                txtDuration.Text = "3 months";
                txtFee.Text = "2200000 (VND)";
            }
            else if (cbCName.SelectedItem.ToString().Equals("OOP"))
            {
                txtDuration.Text = "3 months";
                txtFee.Text = "2800000 (VND)";
            }
            else
            {
               // MessageBox.Show("Course name selected...");
                txtDuration.Text = "";
                txtFee.Text = "";
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string url = "https://www.google.com/";
            System.Diagnostics.Process.Start(url);
        }
    }
}
