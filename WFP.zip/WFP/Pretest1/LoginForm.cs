﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace Pretest1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            setConnect();
        }

        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataSet ds;
        private SqlConnection setConnect()
        {
            string str = "server=.;database=ProductsManagement;uid = sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }
        private void checkLogin()
        {
            string query = "SELECT * FROM Users WHERE UserName = '"+txtUserName.Text+ "'AND Password='" + txtPassword.Text + "' ";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds,"Users");
            if (ds.Tables["Users"].Rows.Count>0)
            {
                this.Hide();
                MDIForm mdi = new MDIForm();
                mdi.Show();
            }
            else
            {
                MessageBox.Show("Username or Password incorrect!");
                txtUserName.Clear();
                txtPassword.Clear();
                txtUserName.Focus();
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtUserName.Text))
                {
                    MessageBox.Show("UserName is required ...");
                    txtUserName.Focus();
                }
                else if (string.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("Password is required ...");
                    txtPassword.Focus();
                }
                else
                {
                    checkLogin();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
