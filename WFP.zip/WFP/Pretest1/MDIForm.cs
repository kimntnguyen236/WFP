﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pretest1
{
    public partial class MDIForm : Form
    {
        public MDIForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.IsMdiContainer = true;
        }

        private void menuLogin_Click(object sender, EventArgs e)
        {
            login = new LoginForm();
            initLogin(login);
            
        }

        private void menuProducts_Click(object sender, EventArgs e)
        {
            products = new ProductsForm();
            initProducts(products);
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            DialogResult message = MessageBox.Show("Are you sure?", "pls check ...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (message == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                // no dothing
            }
        }

        private void menuAbout_Click(object sender, EventArgs e)
        {
            about = new AboutForm();
            initAbout(about);
        }

        // cố định 1 form duy nhất
        LoginForm login;
        private void initLogin(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            login.MdiParent = this;
            login.Show();
        }

        ProductsForm products;
        private void initProducts(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            products.MdiParent = this;
            products.Show();
        }

        AboutForm about;
        private void initAbout(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            about.MdiParent = this;
            about.Show();
        }
    }
}
