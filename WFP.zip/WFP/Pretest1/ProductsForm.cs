﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Pretest1
{
    public partial class ProductsForm : Form
    {
        public ProductsForm()
        {
            InitializeComponent();
            setConnect();
            loadCategoryName();
            loadProducts();
        }
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlDataAdapter adapter1;
        private SqlCommand command;
        private DataSet ds;
        private SqlConnection setConnect()
        {
            string str = "server=.;database=ProductsManagement;uid = sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }
        private void loadCategoryName()
        {
            string query = "SELECT * FROM Categories";
            adapter = new SqlDataAdapter(query,connection);
            ds = new DataSet();
            adapter.Fill(ds, "Categories");
            cbxCategoryName.DataSource = ds.Tables["Categories"];
            cbxCategoryName.DisplayMember = "CategoryName";
        }
        private void loadProducts()
        {
            string queryCategory = "SELECT * FROM Categories";
            string queryProduct = "SELECT ProductID,ProductName,CategoryID FROM Products";
            adapter = new SqlDataAdapter(queryCategory,connection);
            adapter1 = new SqlDataAdapter(queryProduct, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Categories");
            adapter1.Fill(ds, "Products");
            ds.Relations.Add("CaPro", ds.Tables["Categories"].Columns["CategoryID"], ds.Tables["Products"].Columns["CategoryID"],true);

            var bsCate = new BindingSource();
            var bsPro = new BindingSource();

            bsCate.DataSource = ds.Tables["Categories"];
            cbxCategoryName.DataSource = bsCate;

            bsPro.DataSource = bsCate;
            bsPro.DataMember = "CaPro";

            dgvProducts.DataSource = bsPro;
            this.dgvProducts.Columns["CategoryID"].Visible = false;
        }
        private void cbxCategoryName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = dgvProducts.CurrentRow.Index;
            string name = dgvProducts.Rows[row].Cells[1].Value.ToString();
            string queryProduct = "SELECT ProductName,Price as UnitPrice, QuantityPerunit,(Price*QuantityPerunit) as Amount FROM Products WHERE ProductName = '"+name+"'";
            adapter1 = new SqlDataAdapter(queryProduct, connection);
            ds = new DataSet();
            adapter1.Fill(ds, "Products");

            var bsPro = new BindingSource();

            bsPro.DataSource = ds.Tables["Products"];

            dgvDetails.DataSource = bsPro;
        }
    }
}
