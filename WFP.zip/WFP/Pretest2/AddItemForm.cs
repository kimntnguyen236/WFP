﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Pretest2
{
    public partial class AddItemForm : Form
    {
        public AddItemForm()
        {
            InitializeComponent();
            setConnect();
            loadComboBox();
            txtCode.ReadOnly = true;
            txtCode.Text = randomCode();
        }
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlCommand command;
        private DataSet ds;

        public BindingSource bs;

        public SqlConnection setConnect()
        {
            string str = "server=.;database=SupperShoppe;uid=sa;pwd=123";
            connection = new SqlConnection(str);
            return connection;
        }
        public void loadComboBox()
        {
            string sql = "SELECT * FROM Category";
            adapter = new SqlDataAdapter(sql, connection);
            ds = new DataSet();
            bs = new BindingSource();
            adapter.Fill(ds, "Category");
            bs.DataSource = ds.Tables["Category"];
            cbxCategory.DataSource = bs;
            // DisplayMember dùng cho không phải khóa chính
            cbxCategory.ValueMember = "CatCode"; // ValueMember dùng cho khóa chính
        }
        private void CreateItem()
        {
            string query = "INSERT INTO Items VALUES(@code,@desc,@cate,@pri,@q,@com)";
            command = new SqlCommand(query, connection);
            //for (int i = 1; i <= 1000000; i++)
            //{
            //    txtCode.Text = $"{i:00000000}";
            //    break;
            //}
            command.Parameters.AddWithValue("@code",txtCode.Text);
            command.Parameters.AddWithValue("@desc", txtDescription.Text);
            command.Parameters.AddWithValue("@cate", cbxCategory.SelectedValue.ToString());
            command.Parameters.AddWithValue("@pri", txtPrice.Text);
            command.Parameters.AddWithValue("@q", txtQuantity.Text);
            command.Parameters.AddWithValue("@com", txtComments.Text);
            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Customer");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (!Regex.IsMatch(txtDescription.Text, "^[A-Za-z0-9 ]{1,}$"))
                {
                    MessageBox.Show("Description invalid.");
                    txtDescription.Focus();
                    return;
                }
                else if (txtComments.Text == "")
                {
                    MessageBox.Show("Comment invalid.");
                    txtComments.Focus();
                    return;
                }
                else if (!Regex.IsMatch(txtPrice.Text, "^[1-9]{1}[0-9]{0,}$"))
                {
                    MessageBox.Show("Price invalid.");
                    txtPrice.Focus();
                    return;
                }
                else if (!Regex.IsMatch(txtQuantity.Text, "^[1-9]{1}[0-9]{0,}$"))
                {
                    MessageBox.Show("Quantity invalid.");
                    txtPrice.Focus();
                    return;
                }
                else
                {
                    CreateItem();
                    MessageBox.Show("Congratulation");
                    txtCode.Clear();
                    txtComments.Clear();
                    cbxCategory.ResetText();
                    txtPrice.Clear();
                    txtQuantity.Clear();
                    txtComments.Clear();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        string code = "";
        public string randomCode()
        {
            Random random = new Random();
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < 8; i++)
            {
                str.Append(random.Next(9).ToString());
            }
            code = str.ToString();
            return code;
        }
    }
}
