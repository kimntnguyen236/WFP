﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Pretest2
{
    public partial class CategoryForm : Form
    {
        public CategoryForm()
        {
            InitializeComponent();
            setConnect();
            loadCategory();
        }

        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlCommand command;
        private DataSet ds;
        private SqlConnection setConnect()
        {
            string str = "server=.;database=SupperShoppe;uid = sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void loadCategory()
        {
            string query = "SELECT * FROM Category";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Category");
            var bs = new BindingSource();
            bs.DataSource = ds.Tables["Category"];
            dataGridView1.DataSource = bs;

        }
    }
}
