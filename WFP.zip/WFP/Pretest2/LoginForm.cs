﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Pretest2
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            setConnect();
        }
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private DataSet ds;
        private SqlConnection setConnect()
        {
            string str = "server=.;database=SupperShoppe;uid = sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtName.Text))
                {
                    MessageBox.Show("UserName is required ...");
                    txtName.Focus();
                }
                else if (string.IsNullOrEmpty(txtPass.Text))
                {
                    MessageBox.Show("Password is required ...");
                    txtPass.Focus();
                }
                else
                {
                    checkLogin();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void checkLogin()
        {
            string query = "SELECT * FROM [User] WHERE UserName = '" + txtName.Text + 
                "'AND [Password]='" + txtPass.Text + "' AND [Status] = 1 ";
            adapter = new SqlDataAdapter(query, connection);
            ds = new DataSet();
            adapter.Fill(ds, "Users");
            if (ds.Tables["Users"].Rows.Count > 0)
            {
                MessageBox.Show("Congratulation!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Username or Password incorrect!");
                txtName.Clear();
                txtPass.Clear();
                txtName.Focus();
            }
        }
    }
}
