﻿namespace Pretest2
{
    partial class SupperShoppe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupperShoppe));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.menuAddCategory = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuAddItem = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuUpdateStock = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.LogOut = new System.Windows.Forms.ToolStripLabel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAddCategory,
            this.toolStripSeparator1,
            this.menuAddItem,
            this.toolStripSeparator2,
            this.menuUpdateStock,
            this.toolStripSeparator3,
            this.LogOut});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(800, 47);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // menuAddCategory
            // 
            this.menuAddCategory.Image = ((System.Drawing.Image)(resources.GetObject("menuAddCategory.Image")));
            this.menuAddCategory.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.menuAddCategory.Name = "menuAddCategory";
            this.menuAddCategory.Size = new System.Drawing.Size(105, 44);
            this.menuAddCategory.Text = "Add Category";
            this.menuAddCategory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.menuAddCategory.Click += new System.EventHandler(this.menuAddCategory_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 47);
            // 
            // menuAddItem
            // 
            this.menuAddItem.Image = global::Pretest2.Properties.Resources.icons8_mango_32;
            this.menuAddItem.Name = "menuAddItem";
            this.menuAddItem.Size = new System.Drawing.Size(71, 44);
            this.menuAddItem.Text = "Add Item";
            this.menuAddItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.menuAddItem.Click += new System.EventHandler(this.menuAddItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 47);
            // 
            // menuUpdateStock
            // 
            this.menuUpdateStock.Image = global::Pretest2.Properties.Resources.icons8_Strawberry_32;
            this.menuUpdateStock.Name = "menuUpdateStock";
            this.menuUpdateStock.Size = new System.Drawing.Size(98, 44);
            this.menuUpdateStock.Text = "Update Stock";
            this.menuUpdateStock.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.menuUpdateStock.Click += new System.EventHandler(this.menuUpdateStock_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 47);
            // 
            // LogOut
            // 
            this.LogOut.Image = global::Pretest2.Properties.Resources.icons8_avocado_32;
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(62, 44);
            this.LogOut.Text = "Log Out";
            this.LogOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // SupperShoppe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.toolStrip1);
            this.Name = "SupperShoppe";
            this.Text = "SupperShoppe";
            this.Load += new System.EventHandler(this.SupperShoppe_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton menuAddCategory;
        private System.Windows.Forms.ToolStripLabel menuAddItem;
        private System.Windows.Forms.ToolStripLabel menuUpdateStock;
        private System.Windows.Forms.ToolStripLabel LogOut;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
    }
}

