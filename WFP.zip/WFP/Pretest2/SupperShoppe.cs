﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Pretest2
{
    public partial class SupperShoppe : Form
    {
        public SupperShoppe()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            this.IsMdiContainer = true;
        }
        private void menuAddCategory_Click(object sender, EventArgs e)
        {
            category = new CategoryForm();
            initCategory(category);
        }

        CategoryForm category;
        private void initCategory(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            category.MdiParent = this;
            category.Show();
        }

        private void menuAddItem_Click(object sender, EventArgs e)
        {
            addItem = new AddItemForm();
            initAddItemForm(addItem);
        }

        AddItemForm addItem;
        private void initAddItemForm(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            addItem.MdiParent = this;
            addItem.Show();
        }
        private void menuUpdateStock_Click(object sender, EventArgs e)
        {
            updateItem = new UpdateStockForm();
            initUpdateStockForm(updateItem);
        }

        UpdateStockForm updateItem;
        private void initUpdateStockForm(Form form)
        {
            foreach (Form item in MdiChildren)
            {
                if (item.Text.Equals(form.Text))
                {
                    return;
                }
            }
            updateItem.MdiParent = this;
            updateItem.Show();
        }

        private void LogOut_Click(object sender, EventArgs e)
        {
            //foreach (Form f in this.MdiChildren)
            //{
            //    if (this.ActiveMdiChild != f)
            //    {
            //        f.Hide();
            //        LoginForm log = new LoginForm();
            //        log.ShowDialog();
            //    }
            //}
            category.Visible = false;
            addItem.Visible = false;
            updateItem.Visible = false;
            LoginForm log = new LoginForm();
            log.ShowDialog();
        }

        private void SupperShoppe_Load(object sender, EventArgs e)
        {
            LoginForm log = new LoginForm();
            log.ShowDialog();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
