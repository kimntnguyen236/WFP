﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Pretest2
{
    public partial class UpdateStockForm : Form
    {
        public UpdateStockForm()
        {
            InitializeComponent();
            setConnect();
            bindingData();
            txtCategory.ReadOnly = true;
            txtPrice.ReadOnly = true;
        }
        private SqlConnection connection;
        private SqlDataAdapter adapter;
        private SqlCommand command;
        private DataSet ds;

        private BindingSource bs;
        private SqlConnection setConnect()
        {
            string str = "server=.;database=SupperShoppe;uid = sa; pwd = 123";
            connection = new SqlConnection(str);
            return connection;
        }
        private void bindingData()
        {
            string query = "Select * from [Items] ";
            command = new SqlCommand(query, connection);
            adapter = new SqlDataAdapter(command);
            ds = new DataSet();
            adapter.Fill(ds, "Items");
            bs = new BindingSource();
            bs.DataSource = ds.Tables["Items"];
            cbxItem.DataSource = ds.Tables["Items"];
            cbxItem.DisplayMember = "ItemCode";
            txtCategory.DataBindings.Add("Text", ds.Tables["Items"], "ItemDesc");
            txtPrice.DataBindings.Add("Text", ds.Tables["Items"], "Price");
            txtQuantity.DataBindings.Add("Text", ds.Tables["Items"], "Qoh");
            txtComment.DataBindings.Add("Text", ds.Tables["Items"], "Comp");
        }
        private void UpdateData()
        {
            string query = "Update [Items] set qoh = @qoh, comp = @comp  where ItemCode = @code";
            command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@qoh", int.Parse(txtQuantity.Text));
            command.Parameters.AddWithValue("@comp", txtPrice.Text);
            command.Parameters.AddWithValue("@code", cbxItem.GetItemText(cbxItem.SelectedItem));
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateData();
                MessageBox.Show("Success!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
